﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolucaoJV.Domain.Entities
{
    enum TipoJogador
    {
        X, O
    }
}
