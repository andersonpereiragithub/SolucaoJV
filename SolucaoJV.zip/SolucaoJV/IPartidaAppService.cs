﻿namespace SolucaoJV.V
{
    internal interface IPartidaAppService
    {
    }
}